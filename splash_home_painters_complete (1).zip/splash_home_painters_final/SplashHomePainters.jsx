
export default function SplashHomePainters() {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <img src="logo.png" alt="Splash Home Painters Logo" className="logo" />
      <h1>Splash Home Painters</h1>
      <p>Your Walls, Our Passion</p>
      <p>Professional painting services in Hyderabad.</p>
      <p>Call us: <a href="tel:8184888840">8184888840</a></p>
    </div>
  );
}
